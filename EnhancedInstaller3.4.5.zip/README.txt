This program will install some mods on your minecraft, you must have MinecraftForge installed (you'll see a link if isn't installed)
Please make sure you have java installed before use the installer

============= HOW TO INSTALL (windows) =======================

Launch EnhancedInstaller exe and follow instructions

============= HOW TO INSTALL (other) =======================

Launch EnhancedInstaller.jar, download the mod and put it in the "mods" folder of MinecraftForge

============= BUGS =======================

If you have some bugs with the program, launch EnhancedInstallerDebug (in folder "Others") and report your problem of the official minecraftforums post with the log


Mystical