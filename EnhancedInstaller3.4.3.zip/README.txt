This program will install some mods on your minecraft, you must have MinecraftForge installed (you'll see a link if isn't installed)

============= HOW TO INSTALL (windows) =======================

Launch EnhancedInstaller and follow instructions

============= HOW TO INSTALL (other) =======================

There isn't any installer for linux and mac and you must put the mod manually by going on the website, download the mod and put it in the "mods" folder of MinecraftForge

============= BUGS =======================

If you have some bugs with the program, launch EnhancedInstallerDebug (in folder "Others") and report your problem of the official minecraftforums post with the log


Mystical