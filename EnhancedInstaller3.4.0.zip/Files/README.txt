This program will install some mods on your minecraft

============= HOW TO INSTALL (windows) =======================

Launch EnhancedInstaller and follow instructions

============= HOW TO INSTALL (other) =======================

There aren't any launcher for linux/mac, you must install the mod manually by going on the website and download the mod

============= BUGS =======================

If you have some bugs with the program, launch EnhancedInstallerDebug.exe and send the log to the support (www.lordphantomuniverse.fr/contact)
Remember that if you rename the file, you'll see some translation bugs

============= LANGUAGE =======================

Your language is detected by the installer (if it doesn't exists, the installer will use the english).
If you want an specific language you must use --lang:<you lang in format : en_US for english, fr_FR for france...> in command line argument

Avaibles languages are English(en_US) and French(fr_FR)


LordPhantom